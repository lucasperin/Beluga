package syntacticTree;

import parser.*;


public class NullConstNode extends ExpreNode {
    public NullConstNode(Token t) {
        super(t);
    }
}
