package syntacticTree;

import parser.*;


public class IntConstNode extends ExpreNode {
    public IntConstNode(Token t) {
        super(t);
    }
}
