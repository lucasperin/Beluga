package syntacticTree;

import parser.*;


public class NopNode extends StatementNode {
    public NopNode(Token t) {
        super(t);
    }
}
